# Change log

## 1.0 — 2026-10-20

Initial reference-first ImageGen skill, based on10 catalog worker histories. Adds truthful review states, recovery before regeneration, one scoped correction, verified registration and a private timing/quality ledger. Each30 completed distinct catalog entries requires review and a0.1 revision. No instrumented production timing baseline exists yet.
