import assert from 'node:assert/strict';
import {receipt} from './receipt.mjs';
import {versionFor,metrics} from './statistics.mjs';
export function createLedger(){return {schemaVersion:1,entries:[],reviews:[]};
}
export function checkLedger(s){assert.equal(s.schemaVersion,1,'Unknown ledger schema');
assert(Array.isArray(s.entries)&&Array.isArray(s.reviews),'Invalid ledger');
assert.equal(new Set(s.entries.map(r=>r.entryId)).size,s.entries.length,'Duplicate ledger entry IDs');
assert(s.entries.length>=s.reviews.length*30,'Ledger claims a future review');
assert(s.entries.length<=s.reviews.length*30+30,'Ledger crossed an unreviewed boundary');
for(let n=0;n<s.entries.length;n++){const row=receipt(s.entries[n]);assert.equal(row.skillVersion,versionFor(Math.floor(n/30)*30),'Stored row version differs');assert.equal(row.elapsedMs,s.entries[n].elapsedMs,'Stored elapsed time differs');}
for(let i=0;
i<s.reviews.length;
i++){assert.equal(s.reviews[i].through,(i+1)*30);
assert.equal(s.reviews[i].version,versionFor((i+1)*30));
assert(/^[a-f0-9]{64}$/.test(s.reviews[i].packageSha256),'Missing reviewed package digest');
assert(['retain','improve'].includes(s.reviews[i].decision),'Missing review decision');
assert(typeof s.reviews[i].rationale==='string'&&s.reviews[i].rationale.trim().length>=20,'Missing review rationale');
}return s;
}
export function recordEntry(state,input){
 const s=structuredClone(checkLedger(state)),r=receipt(input);

 if(s.entries.some(e=>e.entryId===r.entryId))return {state:s,recorded:false,summary:summarize(s)};

 assert(s.entries.length<(s.reviews.length+1)*30,'30-entry review required before the next entry');

 assert.equal(r.skillVersion,versionFor(s.reviews.length*30),'Receipt uses a different active skill version');

 s.entries.push(r);
return {state:s,recorded:true,summary:summarize(s)};

}
export function summarize(state){
 const s=checkLedger(state),count=s.entries.length,through=s.reviews.length*30,rows=s.entries.slice(through),reviewDue=count===through+30;

 const groups={};
for(const r of rows){const key=r.method+':'+r.difficulty;
(groups[key]??=[]).push(r);
}
 return {completedEntries:count,activeVersion:versionFor(through),earnedVersion:versionFor(count),entriesPerRevision:30,entriesUntilReview:reviewDue?0:30-rows.length,reviewDue,window:metrics(rows),matchedGroups:Object.fromEntries(Object.entries(groups).map(([k,v])=>[k,metrics(v)])),releasedReviews:s.reviews.length};

}
