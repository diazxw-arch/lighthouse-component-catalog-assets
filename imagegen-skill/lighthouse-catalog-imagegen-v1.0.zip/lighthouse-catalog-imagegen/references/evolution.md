# Evolution after every 30 entries

Version 1.0 begins with zero measured entries. Existing catalog history informs the starting method, but is not retroactively counted as newly instrumented work. A completed entry has an inspected candidate, successful storage and catalog refresh/readback, opened stored image and checkpoint. A fully processed `needs-correction` entry counts while remaining unready. Incomplete generation, blocked refresh and uninspected output do not count. Each catalog ID counts once across this skill's ledger; retries, versions and duplicate receipts do not inflate it.

At exactly 30 entries the next version is 1.1, at60 it is1.2, at270 it is1.9, and at300 it is2.0. Integer-tenths arithmetic prevents floating-point drift. The recorder returns `reviewDue:true` and blocks a new entry until the due review release is recorded. More than one producer must use the same explicit ledger; separate ledgers are separate runs, not a global counter.

For each window of30, inspect:

- elapsed median and p90 from reference preparation through verified registration; generation-call and active time separately, with measured sample counts;
- first-pass ready rate (`reviewed` on one attempt), correction rate, attempts per entry and known defect counts;
- five quality dimensions and hard failures in text, icon geometry, protected media or visible state;
- difficult vs easy tasks, recovery/registration delays and repeated file/context reads.

Compare methods on matched difficulty and component types under the same rubric. Faster easy tasks do not establish a faster method. Do not trade Japanese accuracy, original icon weight, protected artwork or registration proof for speed. If the sample is too small or quality is worse, retain the current method and say why. There is no measured speedup in v1.0.

Create the next revision in a staging directory outside active skill discovery. Update VERSION.json by0.1 and set completedEntriesAtRelease to the exact boundary. Update the known-error guide and change log even if the decision is “retain current method; insufficient evidence for a change.” Preserve previous revisions. Run scenario tests and counter tests, NVIDIA SkillSpector `--no-llm`, and source-aware review of the exact package and runtime. Fix findings; install only approved exact bytes. Publish the matching website package/metrics snapshot using its existing owner workflow, preserving the public audience.

Then create a review-release receipt with: `through` (30,60,…), `version`, `decision`, `rationale`, `errorsReviewed`, `timingReviewed`, `qualityReviewed`, `testsPassed`, `scanPassed`, `sourceReviewPassed`, `websitePublished`, and `packageSha256`. The booleans must reflect actual evidence. `packageSha256` is printed by `report --package <directory>` and includes all non-hidden files in the skill package. The `review` command checks the staged package version, boundary and digest before allowing more entries. If installation or publication is blocked, retain the due review and report that blocker; do not claim the revision shipped.

Only aggregate, non-sensitive results belong on the website. Private prompts, worker IDs, machine paths, chat transcripts and source screenshots stay in their existing stores. An agent following this skill performs the due review as part of production; the installed package remains read-only during production. Revisions are prepared separately and released through the reviewed owner workflow. Paused chats remain paused.
