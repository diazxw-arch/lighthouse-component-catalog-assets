# Timing, quality and version releases

## One private ledger for all users of this skill

Use the canonical catalog checkpoint's `component-skill-cycle/` ledger, shared by implementation owners with one writer at a time. On another catalog initialize its own ledger once. Never initialize per worker/batch, lose the counter on compaction or include the historical baseline again. The website is a public read-only snapshot, not a live counter or background worker.

The package's baseline excludes the 155 distinct IDs already accepted at skill creation (154 new deliveries plus the original seed). It is an exclusion list, not proof that historic inputs are current or timing measurements. The original release started at v1.0 and 0/10; a new catalog now starts with the reviewed package version and zero completions. Existing ledgers retain their current version/history. Unknown active/waiting time is `null`, not zero. Record actual start/completion timestamps; pause duration belongs in elapsed time and measured blocked time, not active work. Do not estimate measured fields from chat token counts. Shared batch review/build/deploy overhead is allocated once across its members, with the allocation method in the evidence.

## Tracker commands

The dependency-free Node tracker reads only explicit local paths. It never builds, deploys, installs skills, contacts a network, resumes chats or schedules itself. Review it under the current skill-inspection rules before executing a changed copy.

PowerShell example (replace paths with your actual catalog and reviewed package):

```powershell
$catalog = 'C:/path/to/catalog'
$skill = 'C:/path/to/lighthouse-catalog-component-builder'
$ledger = Join-Path $catalog '.local/component-skill-cycle'
node "$skill/scripts/cycle.mjs" init --store $ledger --workspace $skill --baseline baseline.json
node "$skill/scripts/cycle.mjs" status --store $ledger
node "$skill/scripts/cycle.mjs" record --store $ledger --workspace $catalog --receipt .local/component-receipts/LH01-0123.json
```

Use receipt.template.json as a schema example, not a completed receipt. All nine gates must pass for the same ordered input manifest: visual, interaction, responsive, accessibility, tests, independentReview, ci, production and actualCatalog. Supply relative paths and SHA-256 pins for each input and evidence file; `inputHash` is SHA-256 of `JSON.stringify(inputs)` in recorded order. Pin source, reference and relevant build/host inputs. Each proof must describe its actual scope; the tracker validates pins and required fields, not the truth of a visual or reviewer claim. Use a real independent reviewer. Reused observations retain their true date; record a new acceptance interval encompassing the valid observation, and explain prior active time instead of falsifying dates.

`quality` records first-pass result, review rounds, open defects (must be empty for completion) and honest residuals. Excluded/unobserved physical-device/native-edit/pixel-perfect claims are residuals, not passes. `cleanup` is complete, retained or deferred with an explicit reason. Deferred shared-library cleanup is separate from verified component delivery, and never called completed cleanup.

The tracker rejects missing/stale gates, changed file hashes, duplicate/baseline IDs, self-review, path escapes, symlinks and impossible measured durations. An exclusive lock and atomic replacement preserve the old ledger on failed validation. A stale lock needs inspection of its owning operation before manual recovery. Keep this private state and receipts out of the public site.

## Required review at 10, 20, 30…

The parent owns per-entry learning notes, acceptance records and skill releases. Component website publication remains every 30 source candidates; skill review is every 10 accepted components. Partial source/render handoffs never enter this accepted counter. For the existing zero-completion 30-entry ledger, use the reviewed `migrateEmptyCycle` function through `mutateStore` once, retaining a backup and all events/baseline exclusions. It refuses nonempty ledgers; never reset accepted history to change cadence. This policy revision does not advance version 1.0 or claim a completed cycle.

The 10th completion sets reviewDue. The 11th is refused until review. Record notes/errors continuously; do not wait 10 to fix a defect.

1. Compare the last 10 by family/complexity and scope. Report elapsed/active/wait/rework median and p90, unknown counts, first-pass fraction, defects, review rounds and residuals. Avoid comparing a hard dialog batch to simple controls as a speed improvement.
2. Inspect failure evidence and corrections. Keep better proven methods; remove repeated loops, stale task recovery, duplicated asset hashing and invalid evidence refreshes. Preserve actual visual/interaction/accessibility/independent-review/CI/release checks. Faster by skipping quality is rejected.
3. Review methods with comparable observed samples. `adopt` needs positive before/after measured time, a faster result, no quality regression and all gates preserved. Otherwise `retain` the method and document the finding. A necessary quality repair can be retained as the proven baseline without claiming a speed win.
4. The authorized parent prepares a separate versioned package outside active skill/plugin discovery roots. Its SKILL.md, manifest, changelog and affected references/tests describe that reviewed release. Installed skill files remain read-only during component runs; the receipt runtime never rewrites them. Version uses integer tenths: 1.0 → 1.1 → … → 1.9 → 2.0. Static-inspect the exact staged package and pass its relevant tests before the parent installs or publishes it under the existing human authorization. Preserve prior release archives/checksums and honor Stop/Pause boundaries.
5. Only when the package release is delivered, create a pinned review receipt with `from`, `to`, `decision`, `findings`, `knownErrors`, `reviewer`, `methods` and `evidence` (file/path SHA-256 of release/review proof). Run:

```powershell
node "$skill/scripts/cycle.mjs" review --store $ledger --workspace $catalog --review .local/component-receipts/workflow-1.1.json
```

The next component must use the new version. `review` advances the ledger exactly 0.1 and retains all component/review events. It does not silently edit the package or publish for you. Generate public progress from ledger status only after fresh observation; include the observation date. Never expose private receipt paths or fabricate live updates. No automation is required or authorized by this skill.

## First reviewed cycle and website contract

The first 10 accepted entries span learning/reflection and reader-utility families. Active authoring, blocked and active rework measurements are unknown for every entry. The recorded verification interval begins at the first retained observation and includes waiting and coordination; it is not authoring time. Browser/build phase timings remain separately attributed, and shared overhead is recorded once with its allocation method.

Nine entries passed the first parent actual-catalog audit; one required a narrow-layout correction. This first-pass metric describes that specific published-catalog check, not first implementation or first source review. Preserve source-review rounds, defects, fixes and residuals separately. Use comparable family/complexity and actual phase scope in future comparisons. With no comparable measured active-time samples, retain the method and make no speed claim.

Each reviewed skill release publishes the exact package, ZIP, SKILL.md, checksum manifest, skill page and homepage/catalog version links in the same 10-entry cycle. Verify the deployed labels, link destinations and artifact hashes. This does not wait for the 30-candidate component batch. Save-only or failed hosting publication is incomplete; keep the previous reviewed public release until the replacement succeeds. Never count new baseline/history entries or fabricate gates to reach the threshold.

For a new catalog only, init reads the version and ten-entry cadence from the reviewed package manifest supplied as workspace. Existing stores refuse init and keep their accepted history/version. Upgrade an existing ledger only through the pinned completed-cycle review command; never reset it to install a newer package.

The local ledger requires a trusted single-owner filesystem and cooperating writers using cycle.lock. File existence is checked separately from parsed state under the held lock, so init refuses even an existing null/false/0 file. Atomic rename is not a claim of hostile-filesystem isolation or fsync/power-loss durability. Inspect a leftover lock and its owner before explicit recovery; never delete it blindly.

## Second reviewed cycle

The next10 accepted entries are grammar/lesson guidance and lecture/dialogue families. Nine passed the initial parent actual-catalog audit;135initially failed an audit harness assumption about its deliberately disabled completed-state radio and passed an explicit supplement. All10 cleared the required final gates after earlier source/render review and the scoped130punctuation correction. This is not a measured improvement over the first cycle: family/complexity differs and active authoring, waiting and rework duration remain unknown10/10. Retain methods; make no speed gain claim. Record actual per-ID browser-check elapsed time separately and do not allocate the shared application-build time without a stated method.

When gathering evidence, reconcile explicit successful supplements by ID and state; retain the failed original audit and its cause. A verification interval begins at the earliest actual responsive or interaction observation for the accepted inputs. It is distinct from authoring time. Pin the full unchanged render graph against both its historical capture commit and the delivered source before reusing dated screenshots. Keep historical implementation skillVersion separate from current acceptance review skillVersion; never rewrite old version attestations.

## Third reviewed cycle

The third10 accepted entries cover word learning/controlled recording and reading-plan/editorial guidance. Initial catalog-audit7/10includes two real layout failures (137/138) and a140audit assumption about an intentionally static card. All10cleared final gates. Do not call this a source-first-pass defect rate or compare different families as speed improvement. Active authoring, waiting and rework remain unknown10/10; fresh production browser-check durations are separately recorded per ID.

A broad verification interval can begin at an actual retained source-ready handoff and include subsequent corrections/waiting/coordination. Label that basis; it is not authoring time. Reuse valid source/render observations with their actual dates only after full input-graph identity checks. Keep resolved source findings, layout defects and audit-harness mistakes separate, and preserve each exact successful supplement.
