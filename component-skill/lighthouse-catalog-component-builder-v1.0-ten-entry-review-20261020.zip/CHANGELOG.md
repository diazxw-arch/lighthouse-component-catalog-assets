# Changelog

## Policy revision — 2026-10-20

Direct human instruction changes skill review to every 10 newly accepted distinct components, with exactly +0.1 per completed review. Parent component publication remains every 30 source candidates. Parent owns per-entry learning notes and releases; the worker implements and checks locally. Version stays 1.0 with zero accepted components; this rule change is not a completed learning cycle. Original v1.0 release archives/checksums remain historical.

## 1.0 — 2026-10-20

Initial catalog implementation skill, based on the saved implementation chats, parent acceptance and corrections. Adds exact task restoration, reusable coherent batches, scoped visual rules, actual-catalog sandbox checks, evidence reuse by unchanged input hashes, real release checks and explicit cleanup disposition.

Adds an offline receipt ledger for timing/quality, distinct new component counting and the 30-completion review boundary. Historical deliveries are excluded; no new timing/speed/quality improvement is claimed yet. Next reviewed release is 1.1 after 30 newly verified deliveries. No worker, timer or automation is started.
