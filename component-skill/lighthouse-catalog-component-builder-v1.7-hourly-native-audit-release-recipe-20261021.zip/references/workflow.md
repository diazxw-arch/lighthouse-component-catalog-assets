# Catalog implementation workflow, v1.7

## Authority and recovery

Use native Windows. Read only relevant current pointers; do not scan entire chat histories. Keep one owner, one checkpoint and one acceptance ledger. Latest human scope wins. Other chats, paused research/image queues, global hooks, MCP settings, WSL and dependencies are outside this skill's authority.

Before each batch, save objective, assigned IDs, exact unfinished step, branch/HEAD, changed paths, completed commands after checkpoint, valid evidence hashes, blockers, scoped correction IDs, process ownership and shutdown command. On context restoration, reconcile these against current source and receipts before choosing work. Closed tasks reopen only for a new human request or a specific invalidated check. A final answer about an old task is drift, not backlog completion.

Existing project production rules and CI remain required. Identify overlap before editing shared infrastructure. Reuse a healthy owned preview. A's historical infrastructure ownership is assignment-specific, not a permanent grant to another worker. No background service or recurring automation belongs in the skill.

## Select and measure

Read the actual catalog record and its selected original/Image Gen paths. Inspect images at useful size. Confirm eligibility, current revision and whether a reusable coded implementation already exists. Hash changed source/reference records at acceptance boundaries, not every asset on every poll. Keep provenance and licensed originals. Never replace a working component with an image.

Write a short contract: original crop/bounds, font face/weight/size/line-height/tracking for Japanese and English roles, spacing, states, behavior, app-owned data/callbacks, interaction targets and width-dependent rules. Preserve fine geometry from the original and the approved target. A screenshot is visual evidence, not permission for unrelated redesign.

Capture source message ID/thread, exact new human correction, affected IDs, scoped reusable rule, exceptions, and pending/proved verification. Deduplicate by message ID. Only the parent writes a shared correction log; owner inboxes carry pending feedback. Apply relevant corrections to later work and record their actual check in that item's acceptance.

## Build efficiently

Prefer existing typed primitives and accessible patterns. Batch five compatible items, ten only when coherent. Keep per-item proof even with family reuse. Model controlled state and real host requests. Avoid fake download success, media playback, upload progress or persistence. Distinct color/text/state swaps are one component, not extra completions.

Start the component preview with the component itself. Do not add unrelated reader content, dimension labels, demo chrome or visible credit UI. Preserve required attribution and licenses in deliverables. Preserve meaningful swatch fills and authored themes.

For gestures, capture one pointer, track its actual grab point, cancel safely on disable/capture loss, clamp bounds, provide keyboard controls and accessible boundary feedback. Avoid repetitive live announcements during dragging and no-op undo entries. For dialogs, reuse the installed focus-containment primitive; check outside press, Escape, reopen, focus return and scroll-lock teardown.

## Verify only what needs fresh proof

Compare enlarged original/target/candidate crops and the full result at relevant widths. Normally include 320, 390, 768 and 1280; include the actual iframe width and specific smaller bounds when the component needs them. Check real pointer and keyboard behavior, focus, 44px targets where applicable, overlaps, responsive text, overflow, empty/loading/error/disabled states, console/network/font/media failures and reduced motion when affected. A source assertion or numeric score cannot replace looking at the render.

Exercise the actual catalog preview under its existing `sandbox="allow-scripts"` as well as production. Native form submission may be blocked before its submit event; verify click/Enter and invalid input in that environment and fix the component's request path without widening sandbox permission. This is a context-specific hazard, not a ban on native forms.

Pin proof to input hashes. A changed CSS/reference invalidates affected visual/interaction proof; replay only affected and concretely at-risk shared cases. Never reuse proof across changed inputs. Never change checkedAt to imply a fresh check. Preserve failed/partial tool calls separately from successful final receipts. State unobserved details explicitly: computed font family does not establish document.fonts.status, and desktop emulation is not a physical-device pass.

During edits use focused tests/lint/typecheck. At a batch boundary run required build, independent source/artifact review and CI once for final inputs. The reviewer must differ from the implementer and account for manually excluded files. Use current configured models and permissions, not old model leases. If independent review is unavailable, report it as pending; do not label self-review independent or launch an unauthorized worker.

## Release and cleanup

For the parent's authorized child workflow, the worker hands off local source/checks only. The parent collects 30 distinct source candidates for aggregate publication and owns independent review, CI, production and actual-catalog gates. This supersedes per-five release timing. The parent writes learning notes per entry and performs a +0.1 skill and matching website release every60minutes, without waiting for10 acceptances or blocking entry completion. Keep the two cadences and pending versus accepted evidence separate.

Under current release authorization, commit/push/integrate/deploy and verify immutable production URL, alias, source/build hash mapping and actual catalog route. HTTP 200 returning the SPA shell is not a component. Wait for the relevant deployment terminal state. If Windows CRLF differs from Git LF, prove normalization explicitly instead of claiming raw byte identity.

Record coded, local verified, catalog published, production verified, actual-catalog verified and cleanup disposition independently. Missing/shared publication gates stay pending while independent implementation proceeds. Do not retry a failed launch without a changed prerequisite. Diagnose effective permissions and exact errors; do not revive a resolved access blocker.

FigCraft cleanup follows verified replacements, shared-file dependency and active-writer checks, retained original/generated media and recoverable source. Shared libraries with unreplaced siblings remain retained/deferred with a reason. Do not claim native edit/save/reopen, pixel identity or human acceptance without that exact proof.

Record the qualified delivery once with `cycle.mjs`. Save the next unfinished step. Stop and wait for temporary children; retain a preview only with its owner, PID/session, port, command, cwd and shutdown procedure recorded. Respect a human stop immediately, including during incomplete publication.

## Actual catalog and publication boundaries

Read the actual iframe content width before assessing overflow or hit targets. For iframe-local geometry, read getBoundingClientRect inside that frame; browser page-coordinate bounds need an explicit translation. In a fixed-height preview, verify that internal scrolling and keyboard focus reach lower content/actions. A viewport screenshot does not show the entire component. Recheck only changed and concretely at-risk inputs, preserving the dates of reused proof.

When text source pins differ across Windows/Git, verify lossless UTF-8 and CRLF-only normalization for the specific text file, including SVG/TXT. Font and photographic payloads remain exact bytes. If hosting publication fails, preserve the version/artifact, diagnose once and perform only a bounded attempt after a relevant prerequisite changes. Keep public source documents recoverable and hash-verifiable in the existing immutable asset workflow; a successful transport experiment does not establish the cause of an earlier generic failure.

## Parent publication preflight from the second30 acceptance

Freeze the exact final source and reuse its valid independent source/build proof. Restore the prior canonical Git-blob publication stage before catalog installation: Windows checkout CRLF must not be substituted for committed LF hashes. Preserve binary media/font bytes. Use the existing scoped additive catalog projection when changing only implementations; retain unrelated public entries, counts, dates, media histories and skill links. Check its real validator arguments before invoking it. Keep source documents in the existing reviewed immutable asset transport, and check archive expanded size before publication. These steps add no service, dependency or sandbox permission.

Reuse the complete existing audit helper closure when moving tests into the actual strict catalog iframe. Probe one representative case per affected family before the full audit, then execute every required per-ID/state case. Native radio groups normally have one Tab stop and Arrow navigation. Capture pointer target metadata before an action can hide its underlay. If frame-specific CDP is unsupported for a same-process iframe, inspect that exact iframe document through its parent target; do not alter origin or sandbox restrictions. Verify actual active font embedding separately from unused declared provenance font files. Pin all retained inputs, and never exempt an active font from loading/render checks.

Retain initial failed reports and diagnose whether the failure belongs to the component, audit harness, publication input or external boundary. Rerun only failed and concretely affected scopes, then reconcile successful supplements by exact ID/state/input and observation date. All final visual, keyboard, responsive, accessibility, independent review, build/CI, production and actual-catalog gates remain mandatory. No before/after active-time improvement has yet been measured.


## Restore the release recipe and native audit contract

Restore the last successful command, current CI public build-target variables and exact unfinished phase before launching an aggregate release. Read current CI/environment policy; never print or publish credentials. If the component builds passed but Vite rejected a missing public target, retain the failure and resume only Vite and required delivery guards with the documented target. Do not rebuild unchanged component previews. Avoid overlapping the full test suite with CPU-heavy build/lint/browser phases after observed timeouts. A bounded worker count can preserve assertions and timeouts; retain the initial failures, verify affected tests and obtain one clean required full-suite run before release. This is process concurrency, not authorization for more implementation workers or services.

Before a new browser family audit, inspect the actual preview fixture, visible controls and authored receipt. A conditional status may be absent initially, and a request receipt need not echo the submitted value. Assert the real host-request contract without inventing backend success. Wait for the requested aria-selected/focus state instead of sampling before controlled activation settles. Radix Tabs can include an intentional tabpanel Tab stop; native radio groups and roving toolbars do not have one Tab stop per enabled control. Count actual visible tabbable stops, then verify the family Arrow/Home/End behavior separately. Inputs with labels inside a hidden panel remain hidden; visible-label geometry does not authorize counting hidden controls.

For platform-font inspection, sample an actually visible direct text run. A wrapper with descendant text may report zero direct glyphs; that is not proof of a missing font. Retain the failed probe and sample the rendered text node or owning element. Record active font families/glyph usage separately from computed declarations and source font provenance. Capture available geometry/focus/target metadata before any assertion or screenshot that can fail, preserving useful observations with the failed case. A viewport screenshot tail is not authored component height.

Use distinct immutable report names for failed and successful attempts. Rerun only failed ID/state/width cases, verify exact inputs and retain true observation dates when reconciling supplements. Generic language/name/font/Tab probes supplement the required visual, full functional/state, keyboard/accessibility, strict catalog, production and retention gates; they cannot replace them. The observed parent preparation fixes have no measured accepted-throughput or active-authoring gain yet.
