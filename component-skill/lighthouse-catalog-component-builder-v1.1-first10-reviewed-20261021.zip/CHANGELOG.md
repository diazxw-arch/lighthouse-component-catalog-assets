# Changelog

## 1.1 — 2026-10-21

First 10 distinct newly accepted components reviewed. Retain the existing method: active authoring/wait/rework remain unknown for all 10, so no speed improvement is claimed. Nine passed their first parent actual-catalog audit; the narrow-layout failure was corrected before acceptance. This is a scoped integration-quality observation, not a first-source-pass score.

Clarify actual iframe width and scroll reachability, iframe-local coordinates, bounded UTF-8 text normalization, source-document publication transport and truthful per-stage metrics. Publish the reviewed skill, ZIP, checksums, page and homepage/catalog links in the same 10-entry cycle; component publication remains every 30 source candidates. New-catalog initialization now reads the reviewed package version rather than hardcoding1.0; existing ledgers now refuse reinitialization based on file existence under the lock, including invalid ledger values null/false/0. The receipt example and current headers carry1.1; historical1.0statements are labelled. Baseline exclusions, runtime dependencies and required gates are unchanged.


## Policy revision — 2026-10-20

Direct human instruction changes skill review to every 10 newly accepted distinct components, with exactly +0.1 per completed review. Parent component publication remains every 30 source candidates. Parent owns per-entry learning notes and releases; the worker implements and checks locally. Version stays 1.0 with zero accepted components; this rule change is not a completed learning cycle. Original v1.0 release archives/checksums remain historical.

## 1.0 — 2026-10-20

Initial catalog implementation skill, based on the saved implementation chats, parent acceptance and corrections. Adds exact task restoration, reusable coherent batches, scoped visual rules, actual-catalog sandbox checks, evidence reuse by unchanged input hashes, real release checks and explicit cleanup disposition.

Adds an offline receipt ledger for timing/quality, distinct new component counting and the 30-completion review boundary. Historical deliveries are excluded; no new timing/speed/quality improvement is claimed yet. Next reviewed release is 1.1 after 30 newly verified deliveries. No worker, timer or automation is started.
