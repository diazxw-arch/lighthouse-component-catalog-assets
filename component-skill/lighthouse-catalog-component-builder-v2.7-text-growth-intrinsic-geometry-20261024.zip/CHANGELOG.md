# Version2.7 — text growth in chart and timestamp geometry

Include text dimensions before placing annotations or timestamp rails. Line-height-relative chart positions, max-content timestamp columns and a named keyboard-scrollable region preserve enlarged text without overlap. This bounded lesson comes from LH01-0295/0298, with narrow before/after observations and scoped source repairs. Eight changed group renders were refreshed; twelve unchanged exact-source observations were reused. Current30published candidates passed24/30initial and30/30final Important review, with255exact live routes and30actual-catalog frames. Four host contract keys have static-only aggregate coverage. Following15are source-ready; their dated review state is recorded in manifest.json. No new acceptance, paired skill experiment or measured speed gain. Prior dated snapshots and release archives stay unchanged.

# Version2.6 — sandbox form command dispatch

Use one current-draft callback for explicit buttons and guarded Enter in the actual preview sandbox. Native form submission may be blocked before a submit listener executes. Preserve sandbox permissions and record the received host request. This bounded repair comes from two file-search forms. Current30passed21/30initial and30/30final Important-level review;225live routes match and all30actual-catalog frames were observed. Following5are source-ready with review in progress at this dated snapshot. No new acceptance, paired skill experiment or measured speed gain. Prior review snapshots and release archives remain unchanged.

# Version2.5 — query composition command guard

Guard every query keyboard command during composition, including Escape and arrow/focus commands as well as Enter. A source review found that only Enter was protected in one suggestion field. The repaired five-entry group passed4/5initial and5/5final Important-level review. Current published30passed23/30initial and30/30final; following10passed8/10initial and10/10final. Five more source-ready candidates have review/captures in progress at this dated snapshot. No new acceptance, paired skill experiment or measured speed gain is claimed. Prior release histories remain unchanged.

# Version2.4 — intrinsic auxiliary columns

Reserve side actions and list index rails in intrinsic columns that move with growing content. This bounded workflow change addresses three observed header/rail layout risks. Six200%text observations at320/390 document the repairs. Current published30 passed22/30initial Important-level review and30/30final; following10passed9/10initially and10/10final. No new acceptance, paired skill experiment or measured speed gain is claimed. Earlier review snapshots remain unchanged.

# Version2.3 — intrinsic media labels

Size attachment controls from editable duration labels and wrap the media row as labels grow. This bounded change addresses two observed clipped-caption risks in the current30. Final observations include24px labels at320/390. Retain initial25/30 and final30/30 source review,120final/40superseded render observations,102local requests,135exact live routes and30actual-catalog frames with their actual dates. No new acceptance, paired skill test or measured speed gain is claimed.

# Version2.2 — draft and embedded preview preflight

Record draft commit, intrinsic text growth, accessible content, semantic contrast and embedded focus ownership before implementation. The last published30 had seven affected IDs in initial independent review (23/30), then30/30 after scoped corrections. Retain120final/28superseded render observations,49local host requests,105production routes and30actual catalog previews with their original dates. No new acceptance, paired skill test or comparable speed gain is claimed. This is one current overdue review after interruption; missed hourly releases are not invented.

# Version2.1 — manifest-driven preview routes and durable observations

Build Worker preview routes directly from the reviewed byte manifest, checking exact source/dist bytes and rejecting duplicate or invalid routes. This replaces a stale first-ID update anchor that omitted the next batch before publication. Persist each browser observation before optional requests so unrelated failures retain completed work. Merge parallel catalog registrations normally and reuse component evidence only when exact inputs match. Current30have independent static review,120final responsive renders,74byte-exact production routes and30visible actual-catalog previews. Full acceptance and comparable speed improvement remain unproven; no fresh paired skill test was run.

# Version2.0 — catalog transport and measured viewport preflight

Trace the actual catalog load chain before the next preview batch. A reachable preview URL did not reveal unreadable compressed catalog JSON or missing card bundles. Build now requires immutable routes for all61 relative bundles and runtime verifies their exact size/hash. Actual cards loaded after the v63/v64 repairs. Record real iframe widths before using responsive captures: one initial helper used the default viewport; the corrected30-candidate pass observed320/720px across60renders. Preserve that harness failure separately from component defects. Thirty current candidates have independent static review; full acceptance and comparable speed improvement remain unproven. No fresh paired skill test was run.

# Version1.7 — release recipes, native audit contracts and Site-target preflight

Hourly review addresses observed parent command and browser-harness rework. Restore the current public build target and successful phase recipe, bound full-suite concurrency without changing timeouts, inspect fixture receipt visibility and actual native focus stops, and sample visible direct text for font proof. Resolve the exact ChatGPT Site and source repository; check assigned-entry eligibility from the detail record and image/hash; keep hosted-generation candidates staged until parent review and source pins match. Preserve failed attempts and scoped supplements. Runtime/dependencies unchanged; no new acceptance or measured speed gain.

# Version1.8 — static preview route and archive preflight

For existing-Site preview batches, verify the Worker route map and route bytes before packaging, keep `.openai/hosting.json` at archive root with `dist/` nested, and check every live route after deployment. This batch exposed and fixed three production 404s and one rejected archive layout. Three previews are published, with acceptance still pending. No comparable authoring-time sample or speed gain is claimed.

# Version1.9 — preview overlay change-set preflight

Keep catalog-client injection, exporter allowlist, Worker route map, validator overlay list and byte/hash manifest in one preview-ID change set. This batch caught the exporter-list omission before build. Five local preview pages and route-byte checks are complete; all five catalog records remain acceptance-pending. Active authoring time is unknown, and no speed gain is claimed.

# Version1.6 —100accepted entries/hour target

Human throughput objective100fullyaccepted entries per wall-clock hour; hourly reviews compare rolling1h/3h/24h source and acceptance throughput separately. Target is not achieved speed. Remove repeated parent inventory/serialization and reuse exact validated evidence; retain all quality and publication gates. Correct workflow heading; runtime/dependencies unchanged from inspected1.5. Exact independent review and publication are required for release.

# Version1.5 — restore publication inputs and scoped audit helpers

Hourly review of30new accepted entries (60cumulative). Preserve canonical Git bytes, complete browser helper closure, active-font scope and exact scoped validator inputs before parent release. Retain original failures and rerun only affected cases; preserve all acceptance gates. Active authoring unknown30/30, no measured speed gain. Runtime and dependencies unchanged from inspected1.4.

# Version1.4 — hourly measured workflow improvement

Direct human policy replaces10-accepted-entry releases with hourly skill+website releases. Offline ledger migration preserves historical records; due review no longer blocks completions, and due reviews may include zero accepted entries. Per-entry source-ready/acceptance timing, active/check/review/wait/rework and stage-specific quality/workflow evidence guide bottleneck improvements. No measured speed improvement claimed. All acceptance, source/hash, locking and release-inspection protections remain.

# Changelog

## 1.3 — 2026-10-21

- Third10 accepted entries reviewed; cumulative30,nextcycle0/10. Retain the method; active/wait/rework authoring time remains unknown.
- Initial catalog-audit7/10: two real narrow-layout repairs and one informational-card audit assumption, all resolved before final acceptance. Preserve earlier source recording/hit-routing repairs separately.
- Check the complete render-input graph before evidence reuse. A stale139capture triggered fresh current immutable production282/390captures for10entries; no old observation dates were refreshed.
- Keep shared native files recoverable and retain same10-cycle skill/ZIP/page/checksum/catalog-link publication; no runtime or dependency changes.


## 1.2 — 2026-10-21

- Second10 genuinely accepted entries reviewed; cumulative20, nextcycle0/10. Retain the existing method; no comparable measured active-time improvement is established.
- Record9/10 initial parent actual-catalog audit passes and the135audit-assumption correction for this cycle separately from earlier source/render defects and unknown active/wait/rework authoring time.
- Reconcile exact dated empty-state supplements and use the earliest real responsive/interaction observation for the verification interval. Keep historical implementation1.0 separate from acceptance1.1.
- Keep same10-cycle website/package/ZIP/checksum/page/catalog-link publication and preserve original media, baseline and required gates. No runtime or dependency changes.


## 1.1 — 2026-10-21

First 10 distinct newly accepted components reviewed. Retain the existing method: active authoring/wait/rework remain unknown for all 10, so no speed improvement is claimed. Nine passed their first parent actual-catalog audit; the narrow-layout failure was corrected before acceptance. This is a scoped integration-quality observation, not a first-source-pass score.

Clarify actual iframe width and scroll reachability, iframe-local coordinates, bounded UTF-8 text normalization, source-document publication transport and truthful per-stage metrics. Publish the reviewed skill, ZIP, checksums, page and homepage/catalog links in the same 10-entry cycle; component publication remains every 30 source candidates. New-catalog initialization now reads the reviewed package version rather than hardcoding1.0; existing ledgers now refuse reinitialization based on file existence under the lock, including invalid ledger values null/false/0. The receipt example and current headers carry1.1; historical1.0statements are labelled. Baseline exclusions, runtime dependencies and required gates are unchanged.


## Policy revision — 2026-10-20

Direct human instruction changes skill review to every 10 newly accepted distinct components, with exactly +0.1 per completed review. Parent component publication remains every 30 source candidates. Parent owns per-entry learning notes and releases; the worker implements and checks locally. Version stays 1.0 with zero accepted components; this rule change is not a completed learning cycle. Original v1.0 release archives/checksums remain historical.

## 1.0 — 2026-10-20

Initial catalog implementation skill, based on the saved implementation chats, parent acceptance and corrections. Adds exact task restoration, reusable coherent batches, scoped visual rules, actual-catalog sandbox checks, evidence reuse by unchanged input hashes, real release checks and explicit cleanup disposition.

Adds an offline receipt ledger for timing/quality, distinct new component counting and the 30-completion review boundary. Historical deliveries are excluded; no new timing/speed/quality improvement is claimed yet. Next reviewed release is 1.1 after 30 newly verified deliveries. No worker, timer or automation is started.
